<h1 align="center">系列汇总</h1>

本文主要收集，针对某个问题进行了深入探讨的文章。

每个系列都是精品。

持续更新中……


* [JavaScript是如何工作的系列](https://github.com/qq449245884/xiaozhi)
* [ 前端性能优化 系列](https://github.com/qq449245884/xiaozhi)
* [前端进阶必备，github 优质资源整理分享！](https://juejin.im/post/5d3edad9f265da03a652f133)

- JavaScript的工作原理
  * [JavaScript的工作原理：引擎，运行时和调用堆栈的概述](https://juejin.im/post/5bc86770e51d450e97054ac7)
  * [JavaScript的工作原理：V8引擎内部+关于如何编写优化代码的5个技巧](https://juejin.im/post/5bc98224f265da0af213a09a)
  * [JavaScript的工作原理：内存管理和4种常见的内存泄漏](https://juejin.im/post/5c1737876fb9a049c43d935c)
  * [JavaScript的工作原理：事件循环及异步编程的出现和 5 种更好的 async/await 编程方式](https://juejin.im/post/5c32b971f265da61407f1057)
 
* [JavaScript 数据结构与算法之美](https://github.com/biaochenxuying/blog)
* [stateofjs](https://stateofjs.com/)
* [2018js生态趋势](https://2018.stateofjs.com/cn/introduction/)

* [前端技术栈干货文章链接（精品）](https://zhuanlan.zhihu.com/p/76184208)
* [掘金排行前5000大佬 | 掘金文章排行 看这里](https://juejin.im/post/5d57f9a6f265da03b1204953)
* [the-book-of-secret-knowledge](https://github.com/trimstray/the-book-of-secret-knowledge)
* [2018上半年掘金微信群日报优质文章合集：前端篇](https://juejin.im/post/5b3adfe2e51d4555b17e85df)


