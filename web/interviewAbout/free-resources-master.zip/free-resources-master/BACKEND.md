## python

* [Python - 100天从新手到大师](https://github.com/jackfrued/Python-100-Days)

### 开源
* [如何一小时爬取百万知乎用户信息，并做了简单的分析](https://juejin.im/entry/58e0878f570c3500579eed28)


## jenkins
* [让自动化工作流解放你的双手](https://juejin.im/post/5d3fb5046fb9a06b0935f47d)

