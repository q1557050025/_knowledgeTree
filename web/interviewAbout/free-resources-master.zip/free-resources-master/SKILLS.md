
- mac关闭端口：
```
sudo lsof -i :8100
sudo kill -9 8100
```

- npm清理缓存

```
npm cache clean -f
```

* [Mac Chrome浏览器取消自动升级（看这一篇就够了）](https://blog.csdn.net/chenyufeng1991/article/details/78568919)