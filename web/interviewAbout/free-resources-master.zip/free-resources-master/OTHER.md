* [杭州房产知识扫盲](https://github.com/houshanren/hangzhou_house_knowledge)
* [定投 —— 大佬的自我修养](https://github.com/xiaolai/regular-investing-in-box)
* [把时间当作朋友](https://github.com/xiaolai/time-as-a-friend)
* [我也有话要说](https://github.com/xiaolai/public-speaking-with-meaning)
* [人人都能用英语](https://github.com/xiaolai/everyone-can-use-english)

