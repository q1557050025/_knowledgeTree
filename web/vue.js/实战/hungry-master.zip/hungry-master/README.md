# hungry

* 需要node.js, webpack

* npm i 安装依赖

* npm run serve 运行本地服务器