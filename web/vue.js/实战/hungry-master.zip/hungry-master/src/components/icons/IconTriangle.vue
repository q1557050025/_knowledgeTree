<template>
	<svg viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3876"
	xmlns:xlink="http://www.w3.org/1999/xlink">
	<path
		d="M377.4780684453485 789.1111583709719l279.6549224853515-279.65492248535156-278.8075160980225-278.80751609802246z"
		fill="#000000"></path>
	</svg>
</template>
