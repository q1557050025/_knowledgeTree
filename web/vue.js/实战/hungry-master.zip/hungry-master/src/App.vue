<template>
  <div id="app">
    <transition name="router-fade" mode="out-in">
      <keep-alive>
        <router-view v-if="$route.meta.keepAlive"/>
      </keep-alive>
    </transition>
    <transition name="router-fade" mode="out-in">
      <router-view v-if="!$route.meta.keepAlive" />
    </transition>
    <svg-icon></svg-icon>
  </div>
</template>
<script>
import svgIcon from './components/icon/svg'
export default {
  components: {
    svgIcon,
  }
}
</script>

<style lang="scss">
@import './style/common.scss';
  .router-fade-enter-active, .router-fade-leave-active {
    transition: opacity .6s;
  }
  .router-fade-enter, .router-fade-leave-active {
    opacity: 0;
  }
  #app {
    overflow: hidden;
  }
</style>
