<template>
	<div>
		collect
	</div>
</template>
