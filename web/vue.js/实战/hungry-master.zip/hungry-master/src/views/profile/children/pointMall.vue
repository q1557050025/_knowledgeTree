<template>
	<div>
		pointMall
	</div>
</template>
