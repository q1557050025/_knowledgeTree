<template>
<div>
  <router-link :to="{ name: 'scroll' }">无限滚动</router-link>
  <router-link :to="{ name: 'markdown' }">markdown</router-link>
</div>
</template>