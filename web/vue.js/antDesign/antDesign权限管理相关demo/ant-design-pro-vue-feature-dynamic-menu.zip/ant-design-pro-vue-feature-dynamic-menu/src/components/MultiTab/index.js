import MultiTab from './MultiTab'
import './index.less'

export default MultiTab
