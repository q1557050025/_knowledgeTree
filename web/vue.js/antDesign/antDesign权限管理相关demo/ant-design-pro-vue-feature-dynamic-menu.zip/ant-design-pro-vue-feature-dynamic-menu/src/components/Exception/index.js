import ExceptionPage from './ExceptionPage.vue'
export default ExceptionPage
